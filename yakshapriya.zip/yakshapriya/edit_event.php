
<?php
session_start();


$conn= new mysqli('localhost','root','','yakshapriya');
if(!$conn)
{
	die("connection error".mysqli_connect_error());
}
	$query1 =" SELECT * from event_details  where oid='".$_GET['id']."'";
$result=mysqli_query($conn,$query1);
$row=mysqli_fetch_assoc($result);

$oid=$row['oid'];
$aname= $row['aname'];
	$yname= $row['yname'];
	$date= $row['date'];
	$time= $row['time'];
	$place=$row['place'];
	$sp=$row['sp'];
	$seat=$row['seat'];
	$price=$row['price'];
?>

<?php
if(isset($_POST['update']))
{
	
	
	$oid=$_GET['id'];
	$Artname = $_POST['aname'];
  $Yname = $_POST['yname'];
$date =$_POST['date'];
$time = $_POST['time'];
$place=$_POST['place'];
$sp=$_POST['sp'];
$seat=$_POST['seat'];
$price=$_POST['price'];
	
	
	$conn= new MySQLi('localhost','root','','yakshapriya');
if($conn->connect_error)
{
	die('Connection Failed'.$conn->connect_error);
	
}
else{
	
	
		 $sql="Update event_details SET aname='$Artname' , yname='$Yname' , date='$date' ,time='$time' , place ='$place' , sp='$sp', seat='$seat' , price='$price' where oid='$oid '";
	
	 if($conn->query($sql)===TRUE)
		  {
  		
		  ?><script>alert('Updated records successfully')</script>
<?php
		  }
		else
		 {
  			echo "Error: in sql ";
		 }
	
  			
		  
	  $conn->close();
	
}
	
}

?>

<!doctype html>
<html>
<head>
	<style>
	div
		{
			text-align: center;
		}
		
		 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			height: 20%;
			background: url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: #000000;
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			
			
		}
		.main-nav{
			
			text-align: right;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}
		
			
		
	</style>
	</head>
<body bgcolor="#CDD3CF">
		<div class="header-top">
		<h1 style="color: aliceblue;"> YAKSHAPRIYA</h1>
		<div class="container">
			<a href="#" class=""></a>
			
		</div>
	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
					<li><a href="organiserevents.php">My Events</a></li>
					<li><a href="organiserdetails.php"> Add new event</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="logout.php" onClick="alert('Logged out successfully..')">Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
	

<div>
	

	
<?php
	echo "<form action='' method='post'>";
	
 echo "<h3>Yakshagana name:<input type='text' id='id2'  name='yname' value='$yname'></h3>";
    echo "<h3>Artist name:<input type='text' id='id1' name='aname'  value='$aname'></h3>";
	
	echo "<h3>Date:<input type='date' id='id3'  name='date' value='$date'></h3>";
	echo "<h3>Time:<input type='time' id='id4'  name='time' value='$time'></h3>";
	echo "<h3>Address:<input type='text' id='id5'  name='place' value='$place'></h3>";
	echo "<h3>Special person:<input type='text' id='id6'  name='sp' value='$sp'></h3>";
	echo "<h3>Seat:<input type='number' id='id7'  name='seat' value='$seat'></h3>";
	echo "<h3>Price:<input type='number' id='id8'  name='price' value='$price'></h3>";
	
	echo "<input type='submit' name='update' value='Update'></form>";
	
	?>
</div>
	</body>
</html>
	