<html>
	<?php
	$oi=$_GET['oid']; ?>
<head>
	<style>
		.content{
			margin:auto;
			min-width: 300px;
			font-size: 20px;
			
		}
		.content thead tr{
			width: 600px;
			background-color:rgba(167,167,167,1.00);
			color: aliceblue;
			text-align:center;
			font-weight: bold;
			
		}
		.content tbody td {
			padding: 10px;
			
			
		}
		.content tbody{
			background-color: rgba(209,212,160,1.00);
		}
 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		
		div
		{
			text-align: center;
		}
		
		 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			height: 20%;
			background: url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: #000000;
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			
			
		}
		.main-nav{
			
			text-align: left;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}
		
			
	
	</style>
	</head>
	<body bgcolor="#A899B4">
			<div class="header-top">
		<h1 style="color: aliceblue;"> YAKSHAPRIYA</h1>
		<div class="container">
			<a href="#" class=""></a>
			
		</div>
	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>					<li>	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The form -->
<form class="example" action="booking_search.php" >
  <input type="text" placeholder="Search booking id here"    id="search" name="search" required>
  <button type="submit"><i class="fa fa-search"></i></button>
	<?php echo"<input type='text' name='oid' value='$oi' hidden>" ?>
</form>
					</li>
			<?php	echo"	<li><a href='eventbookings.php?oid=$oi'>All bookings</a></li>" ?>
					<li><a href="organiserevents.php">My events</a></li>
					<li><a href="organiserdetails.php"> Add new event</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="logout.php" onClick="alert('Logged out successfully..')">Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
	
		<h1> YOUR BOOKINGS</h1>
		

<?php
session_start();
	$email=$_SESSION['email'];
		$book=$_GET['search'];
		
		


$conn= new mysqli('localhost','root','','yakshapriya');
	$t="select uid from login where email='$email'";
$result2=mysqli_query($conn,$t);
	$row1=mysqli_fetch_assoc($result2);
	$v=$row1['uid'];
	
if(!$conn)
{
	die("connection error".mysqli_connect_error());
}
	$query10 =" SELECT * FROM event_bookings where bid='$book' and oid='$oi'";
$result5=mysqli_query($conn,$query10);
if(mysqli_num_rows($result5)==0){
		echo"<script> alert('No results found..try again...')</script>";
	   echo"<script>window.location.replace('eventbookings.php?oid=$oi')</script>";
	
			
	}
		else{



$aql="SELECT * from event_bookings  where bid='$book'";
		

$result=mysqli_query($conn,$aql);
		
		if($result->num_rows==0)
		{
			echo"<script>alert('No bookings for this event..')</script>";
		}
		else{
			echo "<table class='content'>";
	echo("<thead>");
	echo("<tr><th>Booking_id</td>" );	
	echo("<th>First name</td>" );
	echo(" <th>Last name</th> ");
	echo(" <th>Phone number</th> ");
	echo("<th>Email</th>");
		echo("<th>Seats</th>");

	
	
	echo("<th> </th>");
	
	
	echo("<th> </th> </tr>");
		
	echo("</thead>");
while($row=mysqli_fetch_assoc($result))
{
	
		$oid=$row['oid'];
		$bid=$row['bid'];
$fname= ($row['firstname']);
$lname= ($row['lastname']);
$num= ($row['Phonenumber']);
$ema=($row['email']);
$seat=($row['seats']);


echo "<form action='' method='post'>";

	echo("<tbody>");
		echo "<tr><td>$bid</td>";
echo "<td>$fname</td>";
echo("<td>$lname</td>");
echo("<td>$num</td>");
echo("<td>$ema </td>");
		echo("<td>$seat</td>");



		
		
	
echo("</tbody");
	echo("</table>");
	echo("</form>");
}
		}
		}


?>