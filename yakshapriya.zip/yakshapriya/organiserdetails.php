<?php

session_start();
$email=$_SESSION['email'];


if (isset($_POST['upload'])) {
	$conn= new MySQLi('localhost','root','','yakshapriya');
	$i="select uid from login where email='$email'";
	$result1=mysqli_query($conn,$i);
	$row=mysqli_fetch_assoc($result1);
	$id1=$row['uid'];
	
	$sql="Select qr from `qrcode` where uid='$id1' ";
	
	$result=mysqli_query($conn,$sql);
		$num=mysqli_num_rows($result);
	if($num>0)
	{
	
	
 $Artname = $_POST['aname'];
  $Yname = $_POST['yname'];
$date =$_POST['date'];
$time = $_POST['time'];
$place=$_POST['place'];
$sp=$_POST['sp'];
$seat=$_POST['seat'];
$price=$_POST['price'];
	$filename = addslashes(file_get_contents($_FILES['uploadfile']['tmp_name']));
	
	

if(!empty($Artname)|| !empty($Yname) || !empty($date) || !empty($time) || !empty($place))
{



$conn= new MySQLi('localhost','root','','yakshapriya');
if($conn->connect_error)
{
	die('Connection Failed'.$conn->connect_error);
	
}
else{
	$i="select uid from login where email='$email'";
	$result1=mysqli_query($conn,$i);
	$row=mysqli_fetch_assoc($result1);
	$id=$row['uid'];
	
	$stmnt=$conn->prepare("insert into event_details(aname,yname,date,time,place,sp,seat,price,filename,uid) values('$Artname','$Yname','$date','$time','$place','$sp','$seat','$price','$filename','$id')");
	$execval = $stmnt->execute();
	if ($execval){
		echo "<script>alert(' Event added successfully!')</script>";
	} else {
		echo "<script>alert('Failed to add event!')</script>";
	}

	


		


  
	   
	
	
  
	$stmnt->close();
	$conn->close();
	
	
}
}

}
	else
{
	
	echo'<script> alert("Please upload your QR code to add events.....")</script>';
		echo"<script>window.location.replace('Qrupload.php') </script>";
		
}
}




?>



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>organiser-details</title>
	<link rel="stylesheet" href="organiser-details.css">
	<script src="https://kit.fontawesome.com/7ecd65510b.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
</head>
	

<body> 
	<div class="navigation">
				 <ul>
					 <li>
						 <a href="#">
							 <span class="icn"><i class="fa-regular fa-address-book"></i></span>
							 <span class="titl">ADD EVENT</span>
						 </a>
					 </li>
					 <li>
						 <a href="organiserevents.php">
							 <span class="icn"><i class="fa-solid fa-eye"></i></span>
							 <span class="titl">VIEW MY EVENTS</span>
						 </a>
					 </li>
					
					 <li>
						 <a href="issueform.php">
							 <span class="icn"><i class="fa-solid fa-eye"></i></span>
							 <span class="titl">ANY ISSUE?</span>
						 </a>
					 </li>
					 
					 <li>
						 <a href="logout.php" onClick="alert('Logged out succesfully..')">
							 <span class="icn"><i class="fa-solid fa-right-from-bracket"></i></span>
							 <span class="titl">LOGOUT</span>
						 </a>
					 </li>
					 <li>
						 <a href="Qrupload.php">
							 <span class="icn"><i class="fa-regular fa-address-book"></i></span>
							 <span  style="opacity: 1" class="titl">UPLOAD MY QR</span>
						 </a>
					 </li>
				 </ul>
				</div>
				
	<div class="container">
		<header><b>EVENT ADDING</b></header>
		<form action="" method="post" enctype="multipart/form-data">
			<div class="form first">
			
				
				<div class="details artist">
					<span class="title" style="color: blue"><h1>Enter Event Details</h1></span>
					
					
					
						<div class="fields">
							
							<div class="input-field">
								<label>Enter artist name*</label>
								<input type="text" id="id1" name="aname" placeholder="Enter name of artist" required>
							</div>
							<div class="input-field">
								<label>Enter Yakshagana Name*</label> 
								<input type="text" id="id2"  name="yname"  placeholder="Yakshagana Name" required>
							</div>
							
							<div class="input-field">
								<label>Date of program*</label>
								<input type="date" id="id3" name="date"   placeholder="" required>
							</div>
						  <div class="input-field">
								<label>Timings*</label>
								<input type="time" id="id4" name="time"  placeholder=":AM/PM" required>
							</div>
							
							
							<div class="input-field">
								<label>Place*</label>
								<input type="text" id="id5" name="place"  placeholder="Write Place " required>
							</div>
							<div class="input-field">
								<label>Special person</label>
								<input type="text" id="id6" name="sp"  placeholder=" eg: Chittani">
							</div>
						 <div class="input-field">
								<label>Total number of seats</label>
								<input type="number" id="id7" name="seat"  placeholder="Total seats" max="500"required>
							 
							</div>
						 <div class="input-field">
								<label>Price per seat</label>
								<input type="number" id="id8" name="price" placeholder="ENTRY FEE">
							 
							</div>
				</div>			
				<div class="imageupload">
					<div class="label">
						<label>upload image here</label>
						 <input  type="file" name="uploadfile" value="" required />
					</div>
	   									
</div>
<button class="btn btn-primary" type="submit" name="upload">SUBMIT</button>
				</div>
</div>										
				</form>		
</div>
</body>
</html>
