<!doctype html>
<html>
<head>

</head>

<body>
	<?php
	echo "<form action='fetch_update.php' method='post'>";
	  $servername="localhost"; 	
	  $username="root";
	  $password="";	
	  $dbName="yakshapriya";

	  $conn1 = new mysqli($servername, $username, $password, $dbName);

	  $sql1 = "SELECT aname ,yname,filename FROM organiserdetails";
		 $result = $conn1->query($sql1);

		if($result->num_rows>0)//when db records are found store in associative array...
		  {
  				// output data of each row
  			echo "  <th><h3> artistname  <th>   " .  "  <th> Yakshaghana name </h3>   <th><br> ";    

  			while( $m=mysqli_fetch_array($result))
  			 {
    			echo "<input type='radio' name='rbRNo' value='" . 
    			$m['aname'] . "'>" . $m['aname'] ;
    			echo " --- " . $m['yname'] . "<br>";
						 ?><img src="./image/<?php echo $m['filename'];?>" width="100" height="100" /><?php
  			 }
      }//if
     else
      {
			  echo " No DB results";
			}

			echo "<input type='submit' value='update'></form>";
?>
</body>
</html>