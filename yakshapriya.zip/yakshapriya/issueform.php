<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<link rel="stylesheet" href="issueform.css">
	<style>
		
		
		img{
			border-radius: 70px;
		}
		
	.output-field{
	position: relative;
	left:500px;
		max-width: 800px;
		max-height: 500px;
    background-color: khaki;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	margin: 10px;
	
}
		.output-field button{
			 background: #EC1F1A;
	border-radius: 40px;
	white-space: nowrap;
	padding: 10px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;

			
		}
		button:hover{
			background-color: green;
		}
		.img img{
			position: absolute;
		}
			
		   h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			
			height: 20%;
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			background:url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: rgba(0,0,0,1.00);
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			height: 10px;
			
			
		}
		.main-nav{
			
			text-align: right;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}

			
		
		
	</style>
</head>
	

<body>
		<div class="header-top">
	
		<h1  style="color: antiquewhite;">  YAKSHAPRIYA</h1>

	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
					
					<li><a href="welcomepage.html">Home</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
	<div class="box1">
		<h1>Any issues?</h1>
		<div class="box2">
	  
	     <form action="" method="post">
			 
			 
			 <div class="input">
				 <label for="id1">Enter Your name:</label><br>
			 <input type="text" name="name" id="id1" placeholder="name" required>
			 
			 </div>
			 
			 
			  <div class="input">
			<label for="id2"> Enter your mobile number:</label><br>
			 <input type="text" name="phno" id="id2" placeholder="+91" required>
			 
			 </div>
			 
			 <div class="input">
				  <label for id="id3">Enter email:</label><br>
				 <input type="text" name="email" id="id3" placeholder="email:"  required>
			
				  </div>
			 
			 <div class="input">
				  <label for="id4">Type your issues:</label><br> 
				<textarea rows="5" name="issue" id="id4"> Enter your issues here:</textarea>
			 
			  </div>
			 <input type="submit" value="submit" name="submit" required>
	           
	     </form>
		</div>
		</div>
	
	<?php
	if (isset($_POST['submit']))
	{
 $name = $_POST['name'];
  $mbl = $_POST['phno'];
$email =$_POST['email'];
$issue = $_POST['issue'];
	
	
	$conn= new MySQLi('localhost','root','','yakshapriya');
if($conn->connect_error)
{
	die('Connection Failed'.$conn->connect_error);
	
}
else{
	
	$stmnt=$conn->prepare("insert into issue (Name,Mnum,Email,Issue) values('$name','$mbl','$email','$issue')");
	$execval = $stmnt->execute();
	if ($execval)
	{
		echo("<script>alert ('Issue sent successfully')</script>");
	}
	
$stmnt->close();
	$conn->close();
}
	
	}
	
	
	
	
	?>
	
</body>
</html>
