<!doctype html>
<html>
<head>
	<style>
		 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		
		div
		{
			text-align: center;
		}
		
		 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			height: 20%;
			background: url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: #000000;
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			
			
		}
		.main-nav{
			
			text-align: right;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}
		
		img{
			
			margin-left: 40%;
		}
		
		form.mid{
			margin-left: 40%;
		}
	.note
		{
			border: 20px;
			background-color: antiquewhite;
		   margin: 10px;
			padding:20px;
			
		}
		.note1{
			color: #ED0D11;
			 font-size: 20px;
		}
		
		
		div.footer{
			
			background-color: lightgreen;
			font-size: 25px;
			text-align: left;
		}
	</style>
	</head>
	<body bgcolor="#A899B4">
			<div class="header-top">
		<h1 style="color: aliceblue;"> YAKSHAPRIYA</h1>
		<div class="container">
			<a href="#" class=""></a>
			
		</div>
	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
					<li><a href="mainpage.php">All Events</a></li>
					<li><a href="userbookings.php">view my bookings </a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="logout.php" onClick="alert('Logged out successfully..')">Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
		<div class="note">
		<p class="note1"><b>Note:</b>Cancellation not available at this moment...please ensure your availabality before you pay... For any queries you can <a href="#footer" >Contact us</a></p>
			
		
		</div>
	
		<h1> Payment section</h1>
		

<?php
  session_start();

$email=$_SESSION['email'];
		
	
		if(isset($_POST['book'])){
			
		
		$_SESSION['rseat']=$_POST['rseat'];
			$_SESSION['nseat']=$_POST['nseat'];
		}
			$conn= new mysqli('localhost','root','','yakshapriya');
			
      	$query1 =" SELECT * from event_details  where oid='".$_GET['oid']."'";
$result=mysqli_query($conn,$query1);
$row=mysqli_fetch_assoc($result);
		$oid=$row['oid'];
$yname= ($row['yname']);
$date= ($row['date']);
$time= ($row['time']);
$place=($row['place']);
$seat=($row['seat']);
$price=($row['price']);
		$ui=$row['uid'];
			
		
		
			
	$rseat=$_SESSION['rseat'];
$seats=$_SESSION['nseat'];
	
	
		
		

	$t="select uid from login where email='$email'";
$result2=mysqli_query($conn,$t);
	$row1=mysqli_fetch_assoc($result2);
	$v=$row1['uid'];
	


		  $seats=$_SESSION['nseat'];
		$tot=$seats*$price;
	
 $qy="select * from qrcode where uid='$ui'";
$result4=mysqli_query($conn,$qy);
$row4=mysqli_fetch_assoc($result4);
   echo '<img  src="data:image/jpeg;base64,'.
	          base64_encode($row4['qr']).'"height="300" width="300"/>'; 
	  ?>
		<form class="mid" action="" method="post">
			<br>
		<?php echo"	<label> Total Amount: $tot </label>"; ?>
			<br>
			<br>
			<label style="font-size: 20px"> UPI transaction id/ref no.:</label>
			<br>
			<input  style="height: 25px" type="text" name="tid" placeholder="Enter transaction id here.." required  maxlength="12/" >
			<br>
			<br>
			<input   style="height: 30px ; background-color: aqua "  type="submit" value="submit" name="submit">
		
		</form>
		<?php 
		
		
			if(isset($_POST['submit']))
			{
				
				$rseat=$_SESSION['rseat'];
              $seats=$_SESSION['nseat'];
				$tid=$_POST['tid'];
			 $status='Pending';
			 
			  $sql1="update event_details SET seat='$rseat' where oid='$oid'";
			mysqli_query($conn,$sql1);
			
			 $sql="select *from registration where email='$email'";
	        
		  $result3=mysqli_query($conn,$sql);
           $row3=mysqli_fetch_assoc($result3);
		
		 $fname=$row3['firstname'];
		 $lname=$row3['lastname'];
		 $number=$row3['Phonenumber'];
		
		
		
		
	$stmnt=$conn->prepare("insert into event_bookings(Tid,firstname,lastname,Phonenumber, email,seats,status,uid,oid) values('$tid','$fname','$lname','$number','$email','$seats','$status','$v','$oid')");
	$execval = $stmnt->execute();

		$stmnt1=$conn->prepare("insert into user_bookings(Tid,yname,date,time,place,seats,status,uid,oid) values('$tid','$yname','$date','$time','$place','$seats','$status', '$v','$oid')");
	$execval = $stmnt1->execute();
				if($conn->query($sql1)===TRUE)
		  {
  		   
				echo"<script>alert('Seats booked successfully...Wait for confirmation..') </script>";
					echo"<script>window.location.replace('mainpage.php')</script>";
				
				
		  
	 
		  }	

			}
			 

		
			 
		 
	?>	
		<footer id="#footer">
	<div class="footer">
		
		Contact us @
		     <br>
		  &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;+919483025205<br>  &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; +916360687621</t><br>
		
		
		</div>
	
	</footer>
	
	</body>
</html>
