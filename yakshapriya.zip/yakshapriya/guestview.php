<!doctype html><?php include('header.php')?>
<html> 
<head>
	
	<style>
		
		h1{
		
			text-align: center;
			text-decoration-color: aquamarine;
			text-shadow: 5px 2px 20px black;
			font-size: 50px;
			
			
		}
		
	

		
	.output-field{
	position: relative;
	left:500px;
		max-width: 800px;
		max-height: 500px;
    background-color: khaki;
	border-radius: 40px;
	white-space: nowrap;
	padding: 40px;
	margin: 10px;
	
}
		.output-field button{
			 background: #EC1F1A;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;

			
		}
		.output-field a{
			 background:#B99898;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;
		}
		a:hover{
			background-color: green;
		}
		
		button:hover{
			background-color: green;
		}
		.img img{
			position: absolute;
			
		
			
		}
		
	</style>
	</head>
<body>
	<br>
	<br>
	<h1>UPCOMING YAKSHAGANA EVENTS</h1>
	<br>
	<br>

	

<?php
$conn= new mysqli('localhost','root','','yakshapriya');
if(!$conn)
{
	die("connection error".mysqli_connect_error());
}
$query1 =" SELECT * FROM event_details";
$result=mysqli_query($conn,$query1);
while($row=mysqli_fetch_assoc($result))
{
	

	$aname= $row['aname'];
	$yname= $row['yname'];
	$date= $row['date'];
	$time= $row['time'];
	$place=$row['place'];
	$sp=$row['sp'];
	$seat=$row['seat'];
	$price=$row['price'];
	
	
	
	
	?>
	<div class="img">
	<?php echo '<img src="data:image/jpeg;base64,'.
	          base64_encode($row['filename']).'"height="500" width="500"/>'; ?>
		</div>
	<?php
	echo "<div id='list' class='output-field'";
	
    echo "<h2></h2><h1>$yname</h1>";
    echo "<h2>Artist name:$aname</h2>";
	
	echo "<h2>Date:$date<h2>";
	echo "<h2>TIME:$time</h2>";
	echo "<h2>Address:$place</h2>";
	echo "<h2>Special person:$sp</h2>";
	echo "<h2>Seat:$seat</h2>";
	echo "<h2>Price:$price</h2>";
	
    echo"<a href='registration.html'   >To book your seats ..Register here</a>";
	echo "</div>";
	echo"<div><br><br><br><br><br></div>";
	
	
}
mysqli_close($conn);

?>
	</div>
	<script>

	</script>
	</body>
	</html>