<html>
<head>
	<style>
		.content{
			
			margin:auto;
			min-width: 300px;
			font-size: 30px;
			
		}
		.content thead tr{
			width: 600px;
			background-color:rgba(167,167,167,1.00);
			color: aliceblue;
			text-align:center;
			font-weight: bold;
			
		}
		.content tbody td {
			padding: 10px;
			
			
			
		}
		.content tbody{
			background-color: rgba(209,212,160,1.00);
		}
 h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		
		div
		{
			text-align: center;
		}
		
	
		.header-top{
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			height: 20%;
			background: url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: #000000;
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			
			
		}
		.main-nav{
			
			text-align: left;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}
		
			.note
		{
			border: 20px;
			background-color: antiquewhite;
		   margin: 10px;
			padding:20px;
			
		}
		.note1{
			color: #ED0D11;
			 font-size: 20px;
		}
		div.footer{
			
			background-color: lightgreen;
			font-size: 25px;
			text-align: left;
		}
	
	</style>
	</head>
	<body bgcolor="#A899B4">
			<div class="header-top">
		<h1 style="color: aliceblue;"> YAKSHAPRIYA</h1>
		<div class="container">
			<a href="#" class=""></a>
			
		</div>
	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
									<li>	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The form -->
<form class="example" action="booking_search2.php" >
  <input type="text" placeholder="Search booking id here"    id="search" name="search" required>
  <button type="submit"><i class="fa fa-search"></i></button>
	
</form>
					</li>
					<li><a href="mainpage.php">All Events</a></li>
					<li><a href="userbookings.php"> View my bookings</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="logout.php" onClick="alert('Logged out successfully..')">Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
		<div class="note">
		<p class="note1"><b>Note:</b>Cancellation not available at this moment...For any queries you can <a href='#footer' >Contact us</a></p>
			
		
		</div>
	
		<h1> YOUR BOOKINGS</h1>
	</body>
</html>

<?php
		
session_start();
	$email=$_SESSION['email'];


$conn= new mysqli('localhost','root','','yakshapriya');
	$t="select uid from login where email='$email'";
$result2=mysqli_query($conn,$t);
	$row1=mysqli_fetch_assoc($result2);
	$v=$row1['uid'];
	
if(!$conn)
{
	die("connection error".mysqli_connect_error());
}
	



$aql="select *from user_bookings where uid='$v'";

$result=mysqli_query($conn,$aql);
		if($result->num_rows==0)
		{
			echo"<script>alert('You did not booked any seats')</script>";
		}
		else{
			
			
			echo "<table class='content'>";
			
	echo("<thead>");
	echo("<tr><th>Booking_id</th>" );
			echo("<th>Transaction_id</th>");
	echo("<th>Yakshagana name</th>" );
	echo(" <th>Date</th> ");
	echo(" <th>Time</th> ");
	echo("<th>Place</th>");
			echo("<th>Number of seats</th>");
			echo("<th>Status</th>");
	
			echo("<th> </th> </tr>");
	
			echo("</thead>");
			

			
while($row=mysqli_fetch_assoc($result))
{
		$oid=$row['oid'];
	    $tid=$row['Tid'];
		$bid=$row['booking_id'];
$yname= ($row['yname']);
$date= ($row['date']);
$time= ($row['time']);
$place=($row['place']);
$seat=($row['seats']);
	$status=$row['status'];
	

echo "<form action='edit_tid.php?oid=$oid&bid=$bid' method='post'>";
	echo("<tbody>");
		echo "<tr><td>$bid</td>";
	echo "<td>$tid</td>";
echo "<td>$yname</td>";
echo("<td>$date</td>");
echo("<td>$time</td>");
echo("<td>$place </td>");
echo("<td>$seat </td>");
	echo("<td style='color:green'>$status</td>");
		
echo "<td><input type='submit' value='Edit transaction_id' name='edit' > </td>";
		
	

	
	



echo("</tbody");
	echo("</table>");
	echo("</form>");
	
	
		
		

		}
		}

		?>
		

	


		

		


	
