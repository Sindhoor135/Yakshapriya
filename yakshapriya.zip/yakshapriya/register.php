<?php


	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$Role = $_POST['Role'];
	$email = $_POST['email'];
	$Phonenumber = $_POST['Phonenumber'];
	$password = $_POST['password'];
	$Confirmpassword = $_POST['Confirmpassword'];
	$gender = $_POST['gender'];
	$recover=$_POST['recover'];
	

	// Database connection
	$conn = new mysqli('localhost','root','','yakshapriya');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	}

	$sql="Select email from `registration` where email='$email' ";
	
	$result=mysqli_query($conn,$sql);
	

	
	if($result)
	{
		$num=mysqli_num_rows($result);
		if($num>0)
	    {
		
			echo'<script> alert("Email is already registered..!! Enter new email..")</script>';
			echo"<script>window.location.replace('registration.html')</script>";
		//	echo' <a  style="color: green;" href="registration.html"><h1>Click here to refresh</a>';
		}
		else
		{
		
		$stmt = $conn->prepare("insert into registration(firstname, lastname, Role, email,Phonenumber,password,Confirmpassword, gender) values(?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param( "ssssisss", $firstname, $lastname, $Role, $email,$Phonenumber, $password,$Confirmpassword ,$gender);
		
		$stmt1 = $conn->prepare("insert into login( Role, email,password) values(?,?, ?)");
		$stmt1->bind_param( "sss",$Role, $email,$password);
		
		$stmt2 = $conn->prepare("insert into passrecovery( email,recover) values(?, ?)");
		$stmt2->bind_param( "ss", $email,$recover);
		
		
		$execval = $stmt->execute();
		$execval1 = $stmt1->execute();
		$execval2 = $stmt2->execute();
	
		echo $execval;
		echo $execval1;
		echo $execval2;
		
		$stmt->close();
		$stmt1->close();
		$stmt2->close();
		$conn->close();
			
		header('Location:login.php');
		
	}
	
	}

			  
?>