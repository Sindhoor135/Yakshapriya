<?php
session_start();
$email=$_SESSION['email'];

?>

<html>
<head>
	<style>
		
		
		img{
			border-radius: 70px;
		}
		
	.output-field{
	position: relative;
	left:500px;
		max-width: 800px;
		max-height: 500px;
    background-color: khaki;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	margin: 10px;
	
}
		.output-field button{
			 background: #EC1F1A;
	border-radius: 40px;
	white-space: nowrap;
	padding: 10px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;

			
		}
		button:hover{
			background-color: green;
		}
		.img img{
			position: absolute;
		}
			
		   h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			
			height: 20%;
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			background:url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: rgba(0,0,0,1.00);
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			height: 10px;
			
			
		}
		.main-nav{
			
			text-align: left;
		
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}

			
		
		
	</style>
	</head>
<body bgcolor="#CDD3CF">
	
	
	<div class="header-top">
	
		<h1  style="color: antiquewhite;">  YAKSHAPRIYA</h1>

	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
						<li>	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The form -->
<form class="example" action="process_search.php" >
  <input type="text" placeholder="Search Yakshagana name here.."    id="search" name="search1" required>
	<button type="submit" value="search" ><i class="fa fa-search"></i></button>
</form>
					</li>

					<li><a href="#">All Events</a></li>
					<li><a href="userbookings.php">My Bookings</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a  href="logout.php"  onClick="alert('logged out successfully..')"  >Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>

	
	
	<br>
	<br>
	<br>
	

<?php
$conn= new mysqli('localhost','root','','yakshapriya');
if(!$conn)
{
	die("connection error".mysqli_connect_error());
}
$query1 =" SELECT * FROM event_details";
$result=mysqli_query($conn,$query1);
while($row=mysqli_fetch_assoc($result))
{
	

	$aname= $row['aname'];
	$yname= $row['yname'];
	$date= $row['date'];
	$time= $row['time'];
	$place=$row['place'];
	$sp=$row['sp'];
	$seat=$row['seat'];
	$price=$row['price'];
	
	
	
	
	?>
	<div class="img">
	<?php echo '<img src="data:image/jpeg;base64,'.
	          base64_encode($row['filename']).'"height="500" width="500"/>'; ?>
		</div>
	<?php
	echo "<div  id='list' class='output-field'";
	
    echo "<h2></h2><h1>$yname</h1>";
    echo "<h2>Artist name:$aname</h2>";
	
	echo "<h2>Date:$date<h2>";
	echo "<h2>TIME:$time</h2>";
	echo "<h2>Address:$place</h2>";
	echo "<h2>Special person:$sp</h2>";
	echo "<h2>Seat:$seat</h2>";
	echo "<h2>Price:$price</h2>";
	?>
	
	 <a href="bookings.php?oid=<?php echo $row['oid'];?>"> <button class='btn'  >BOOK YOUR SEAT </button> </a>
	
    
	</div>
	<div><br><br></div>
	<?php
	
	
}
mysqli_close($conn);

?>
	</div>
	
	
	</body>
	</html>