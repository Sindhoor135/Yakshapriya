<?php

session_start();
$email=$_SESSION['email'];


$conn= new mysqli('localhost','root','','yakshapriya');
	$t="select uid from login where email='$email'";
$result2=mysqli_query($conn,$t);
	$row1=mysqli_fetch_assoc($result2);
	$v=$row1['uid'];

$x=$_GET['oid'];
	$l=$_GET['bid'];
 $sql3="select * from user_bookings where booking_id='".$_GET['bid']."'";
		  
		  $result4=mysqli_query($conn,$sql3);
           $row2=mysqli_fetch_assoc($result4);
$tid=$row2['Tid'];
$status=$row2['status'];
$strt='Confirmed';
if($status==$strt)
{
	 echo("<script>alert('Your seat already confirmed..')</script>");
	echo("<script>window.location.replace('userbookings.php?oid=$x ')</script>");
}
else{
	echo"<form action='' method='post'>";
   echo "<input type='text'  maxlength='12/' name='tid' id='id1' value='$tid' > <br><br>";
echo "<input type='submit' value='Confirm' name='confirm' >";
echo"</form>";
}
?>
<?php
  if(isset($_POST['confirm']))
  {
	  
	  $ti=$_POST['tid'];
	  mysqli_query($conn,"update user_bookings  set Tid='$ti' where booking_id='$l' and oid='$x'");
	  mysqli_query($conn,"update event_bookings  set Tid='$ti' where bid='$l' and oid='$x'");
	  
	  echo("<script>alert('Transaction Id updated successfully..')</script>");
	echo("<script>window.location.replace('userbookings.php?oid=$x ')</script>");
	  
	  
  }



    ?>
