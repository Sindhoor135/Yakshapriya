<?php

$success=0;
$user=0;

if($_SERVER['REQUEST_METHOD']=='POST'){
	session_start();
	$_SESSION['email']=$_POST['email'];
	
	include 'connect.php';
	$email=$_POST['email'];
	$password=$_POST['password'];
	$sql="Select *from `login` where email='$email'  and password='$password' ";
	$sql1="Select Role from `login` where email='$email'";
	$result1=mysqli_query($con,$sql1);
	$result=mysqli_query($con,$sql);
	$c=mysqli_fetch_array($result1);
	if($result){
		$num=mysqli_num_rows($result);
		if($num>0){
			$user=1;
		}
		else{
			$success=1;
			}
			}
		
	}

?>

<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="login.css">
	<style>
	 body {
      
      background-size: cover;
    }
	</style>
</head>
	<body background-image>
		<?php
		if($user){
			if($c['Role']=="Organiser")
			{
		
			header('Location:organiserdetails.php');
			}
			else if($c['Role']=="User")
			{
				header('location:mainpage.php');
			}
			
		}
		?>
		<?php
		if($success){
			echo '
			<strong><h1>  <script>alert("Email and password does not match")</script> </h1></strong>
			
			';
		}
		?>
<div class="wrapper">

    <div class="registration_form">
   <!-- Title --> 
     <div class="title">
       Login 
     </div>
   
   <!-- Form -->
    <form  name="f1" action="login.php" onSubmit="return validation()" method="post">
     <div class="form_wrap">
      <div class="input_grp">
   
     <div class="input_wrap">
       <p>
         <label for="email">Email : <br>
         </label>
         <input type="text" id="email" name="email" placeholder="abcdefgh@gmail.com" onChange="return Email()">
		   <label id="id2" style="visibility: hidden"></label>
       </p>
     
     </div>
		 </div>
		</div>
		    
		    
	  <div class="form_wrap">
      <div class="input_grp">
	    <div  class="input_wrap">
	      <label for="password">password : <br></label>
    <input type="password" id="password" name="password" placeholder="Enter password ">
  </div>
		  </div>
		</div>
		<div class="form_wrap">
      <div class="input_grp">
	   
		   <div class="input_wrap">
      <input type="submit" value="login" class="submit_btn" >
    </div>
			</div>
		</div>
		
		
   
		<div>
			<br>
            <a style="font-size: 15px;" class="submit_btn" href="registration.html">New User?..Register here</a>
			<br><br>
			<a style="font-size: 15px;" class="submit_btn" href="forgotpass.php">Forgot password..?Click here</a>
		</div>
		
		</form>
		</div>
	</div>
		<script>  
            function Email()
		 {
			 
		 
		var x=document.getElementById('email').value;
		var rexp=/^[a-zA-Z0-9+_.-]+@gmail.com$/;
		var n=rexp.test(x);
		
		if(!n)	
		{
		
			document.getElementById("id2").style.visibility='visible';
			document.getElementById("id2").innerHTML="!** Invalid Email **!";
			document.getElementById("id2").style.color="aqua";
			return false;
			
		}
			else
			{
					
				document.getElementById("id2").style.visibility='visible';
			 document.getElementById("id2").innerHTML="";
		
				return true;
			}
		
	}
			
			function validation()
			{
		
				
                var id=document.f1.email.value;  
                var ps=document.f1.password.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("Email and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("Enter your email");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                } 
				
				
		
            }  
			
        </script>  	
</body>
</html>
	