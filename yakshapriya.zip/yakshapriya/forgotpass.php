
	


<?php
$success=0;
$user=0;

if($_SERVER['REQUEST_METHOD']=='POST'){
	include 'connect.php';
	$email=$_POST['email'];
	$password=$_POST['recover'];
	$sql="Select *from `passrecovery` where email='$email'  and recover='$password' ";
	
	$result=mysqli_query($con,$sql);
	$c=mysqli_fetch_array($result);

	if($result){
		$num=mysqli_num_rows($result);
		if($num>0){
			$user=1;
		}
		else{
		$success=1;
			
			}
			}
		
	}

?>
<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="forgotpass.css">
	<style>
	 body {
      background-color: rgba(35,32,32,1.00);
      background-size: cover;
    }
		
	
	 
		
		img{
			border-radius: 70px;
		}
		
	.output-field{
	position: relative;
	left:500px;
		max-width: 800px;
		max-height: 500px;
    background-color: khaki;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	margin: 10px;
	
}
		.output-field button{
			 background: #EC1F1A;
	border-radius: 40px;
	white-space: nowrap;
	padding: 10px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;

			
		}
		button:hover{
			background-color: green;
		}
		.img img{
			position: absolute;
		}
			
		   h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			
			height: 20%;
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			background:url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: #000000;
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			height: 10px;
			
			
		}
		.main-nav{
			
			text-align: right;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: red;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}

			
		
		
	
	</style>
</head>
	
		<body bgcolor="#CDD3CF">
	
	
	<div class="header-top">
	
		<h1  style="color: antiquewhite;">  YAKSHAPRIYA</h1>

	
	</div>
	<div class="header-bottom">

		<div class="container">

			<nav class="main-nav">

				<ul>
							
					

					<li><a href="guestview.php">All Events</a></li>
					<li><a href="registration.html">Register</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="login.php">Login</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>

		<?php
if($user){
			$password=$_POST['password'];
	$Confirmpassword=$_POST['Confirmpassword'];
	
	mysqli_query($con,"update registration set Confirmpassword='$Confirmpassword' where email='$email'");
	mysqli_query($con,"update registration set password='$password' where email='$email'");
	mysqli_query($con,"update login set password='$password'  where email='$email'");
		header('Location:login.php');
			
		}
?>
<?php
if($success) 
{
	
	echo '
			 <script>alert("Email or Security question and answer is incorrect")</script>';	
	
}
	

?>
		  

		
<div class="wrapper">
	<div class="registration_form">
		<form action="forgotpass.php" onSubmit="return Email() && Password() && CPassword()" method="post">
<div class="form_wrap">
	
	<div class="input_wrap">
     <label for="email">Email Address :</label>
     <input type="text" id="email" name="email" required placeholder="abcdefgh123@gmail.com" onChange=" return Email()">
    <span id="id2" style="visibility: hidden;">!! Invalid email !!</span>
		 </div>
    
   
	 <div  class="input_wrap">
      <label  for=" recovery" > Select security question :</label>
      <select style="width: 300px;" name="recover"  Size="1">  
  <option> 1. What is the name of your favorite pet?</option>  
  <option> 2.What's your favorite movie?</option>  
  <option> 3. In which city were you born?</option>  
  <option> 4. What's your nickname?</option>  
</select> 
			  <br>
		 <br>
		 <input type="text" id="recovery" name="recover" required placeholder="Enter your answer" >
			  
	
      </div>
	 <div  class="input_wrap">
    <label for="password">New password :</label>
    <input type="password" id="password" name="password" required placeholder="enter new password" onChange="return Password()" >
   <label id="pass" style="visibility: hidden;"></label>
		 </div>

    <!-- retype passward-->
    <div  class="input_wrap">
      <label  for=" Confirmpassword" > Confirm  new password :</label>
      <input type="password" id="Confirmpassword" name="Confirmpassword" required placeholder="Retype password" onChange="return CPassword()"  >
	<label id="confirmpass" style="visibility: hidden;">password doesn't match</label>
      </div>
	  
	
   <!-- Submit button -->
		  
    <div class="input_wrap">
      <input type="submit" id="create" value="Submit" class="submit_btn"   >
    </div>
   
   

		</div>
		</form>
		</div>
		</div>
   
   
		
		<script>	
			
			
		function Email()
		 {
			 
		 
		var x=document.getElementById('email').value;
		var rexp=/^[a-zA-Z0-9+_.-]+@gmail.com$/;
		var n=rexp.test(x);
		
		if(!n)	
		{
		
			document.getElementById("id2").style.visibility='visible';
			document.getElementById("id2").innerHTML="enter valid email";
			document.getElementById("id2").style.color="red";
			return false;
			
		}
			else
			{
					
				document.getElementById("id2").style.visibility='visible';
			 document.getElementById("id2").innerHTML="";
		
				return true;
			}
		
	}
			
				
			function Password()
		 {
		var password=document.getElementById('password').value;
		var rexp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,50}$/;
		var s=rexp.test(password);
		
		if(!s)
			{
				document.getElementById("pass").style.visibility='visible';
			 document.getElementById("pass").innerHTML="*!! password must contain minimum of 8 characters and must contain atleast one lowercase letter, uppercase, numeric and one special character *!!";
			document.getElementById("pass").style.color="antiquewhite";
				return false;
			}
			 else
			{
					
				document.getElementById("pass").style.visibility='visible';
			 document.getElementById("pass").innerHTML="";
		
				return true;
			}
			
			 		 }
		
		
		
		function CPassword()
		 {
	      var a=document.getElementById('password').value;
		  var b=document.getElementById('Confirmpassword').value; 
	 
		 if(a!=b)
		 {
			 
			 
			 document.getElementById("confirmpass").style.visibility='visible';
			 document.getElementById("confirmpass").innerHTML="Password doesn't match";
			document.getElementById("confirmpass").style.color="red";
			 
			 return false;
		 }
			 else
			{
					
				document.getElementById("confirmpass").style.visibility='visible';
			 document.getElementById("confirmpass").innerHTML="";
		
				return true;
			}
		
			
		
		 }

	
		  
		 
		
			
		

		</script>
	
			</body>
			</html>