<?php

session_start();
$email=$_SESSION['email'];
$conn= new MySQLi('localhost','root','','yakshapriya');
if($conn->connect_error)
{
	die('Connection Failed'.$conn->connect_error);
	
}
else{
	$i="select uid from login where email='$email'";
	$result1=mysqli_query($conn,$i);
	$row=mysqli_fetch_assoc($result1);
	$id=$row['uid'];
}

?>
<html>
	<head>
		<style>
			
			div.qr{
				margin-top: 10px;
				margin-bottom: 1%;
				margin-left: 34%;
				
				align-content: center;
			}
	.label{
	color: black;
	height: 90px;
	width: 250px;
	position:absolute;
	margin:20px;
		
	align-self: center;
	
	padding:10px;
	font-weight: bold;
	font-size: 30px;
	text-align: center;
	border-radius: 20px;
	box-shadow: 5px 5px 5px 5px;
	
	
}

			.label2{
	color: black;
	height: 50px;
	width: 200px;
	
	margin-top: 10%;
				margin-bottom: 15%;
				margin-left: 10px;
		
	
	background: #391CDB;
	padding:0px;
	font-weight: bold;
	font-size: 30px;
	text-align: center;
	border-radius: 20px;
	box-shadow: 5px 5px 5px 5px;
	
	
}
			.label2:hover{
				color: forestgreen;
			}
			
			
			.header-top{
			
			height: 20%;
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			background:url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: rgba(0,0,0,1.00);
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			height: 10px;
			
			
		}
		.main-nav{
			
			text-align: right;
		
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}

	</style>
	</head>
	<body  bgcolor="#747684">
		
	
	
	
	<div class="header-top">
	
		<h1  style="color: antiquewhite;">  YAKSHAPRIYA</h1>

	
	</div>
	<div class="header-bottom">
		<div class="container">
			<nav class="main-nav">
				<ul>
						
					<li><a href="organiserevents.php">My Events</a></li>
					<li><a href="organiserdetails.php">Add Events</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a  href="logout.php"  onClick="alert('logged out successfully..')"  >Logout</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
	<div class="imageupload">
		<div class="qr">
					<div class="label" >
						<form  action="" method="post" enctype="multipart/form-data">
						<label >upload QR code here</label>
						 <input  type="file" name="upl" value=""  required accept="image/jpeg"  ><br><br>
						<input class="label2" type="submit" value="Upload" name="qr">
						
						</form>
					</div>
		</div>
		  
		</body>

</html>
	<?php
	if(isset($_POST['qr'])){
		$sql="Select qr from `qrcode` where uid='$id' ";
	
	$result=mysqli_query($conn,$sql);
		$num=mysqli_num_rows($result);
		if($num>0)
	    {
		
			echo'<script> alert("QR code already exists...!")</script>';
			echo"<script>window.location.replace('organiserdetails.php') </script>";
		}
		else{
		
		$qr = addslashes(file_get_contents($_FILES['upl']['tmp_name']));
		
		$stmnt=$conn->prepare("insert into qrcode(qr,uid) values('$qr','$id')");
	$execval = $stmnt->execute();
	if ($execval){
		echo "<script>alert(' QR code uploaded successfully!')</script>";
		echo"<script>window.location.replace('organiserdetails.php') </script>";
	} else {
		echo "<script>alert('Failed to upload QR!')</script>";
	}

	}
	}
	
	
	?>