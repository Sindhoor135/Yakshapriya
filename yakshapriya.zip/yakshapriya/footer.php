<!doctype html>
<html>
<head>
	<style>
	
		div.footer{
			
			background-color: lightgreen;
			font-size: 25px;
			text-align: left;
		}
	</style>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<footer>
	<div class="footer" >
		Contact us @
		     <br>
		  &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;+919483025205<br>  &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; +916360687621</t><br>
		
		
		</div>
	
	</footer>
</body>
</html>