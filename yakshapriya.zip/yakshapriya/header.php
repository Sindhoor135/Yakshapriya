
<!doctype html>

<html>
<head>
	
	
	<style>
	 
		
		img{
			border-radius: 70px;
		}
		
	.output-field{
	position: relative;
	left:500px;
		max-width: 800px;
		max-height: 500px;
    background-color: khaki;
	border-radius: 40px;
	white-space: nowrap;
	padding: 20px;
	margin: 10px;
	
}
		.output-field button{
			 background: #EC1F1A;
	border-radius: 40px;
	white-space: nowrap;
	padding: 10px;
	font-weight: 500;
	font-size: 20px;
	margin: 10px;

			
		}
		button:hover{
			background-color: green;
		}
		.img img{
			position: absolute;
		}
			
		   h1{
			   text-align: center;
			margin-left: 20px;
		    margin-top: 20px;
			text-decoration-color: whitesmoke;
			text-shadow: 5px 5px 5px brown;
			font-size: 40px;
			
			
		}
		.header-top{
			
			height: 20%;
			background: #E4D2D2;
			padding: 20px;
			text-align: center;
			background:url("kantara.jpg");
			background-size: cover;
		}
		.container{
			max-width: 1100px;
			margin: 0 auto;
		}
			
		.header-bottom{
			background: rgba(0,0,0,1.00);
			padding:20px 0;
			position: sticky;
			top: 0;
			z-index: 999;
			height: 10px;
			
			
		}
		.main-nav{
			
			text-align: left;
		}
		.main-nav ul{
			padding: 0;
			margin: 0;
			list-style: none;
		}
		.main-nav ul li{
			display: inline-block;
			margin-left: 30px;
			
		}
		.main-nav ul li a{
			color: aliceblue;
			font-weight: bold;
			text-decoration: none;
			
		}
		.main-nav ul li a:hover{
			color:cornflowerblue;
		}

			
		
		
	</style>
	</head>
<body bgcolor="#CDD3CF">
	
	
	<div class="header-top">
	
		<h1  style="color: antiquewhite;">  YAKSHAPRIYA</h1>

	
	</div>
	<div class="header-bottom">

		<div class="container">

			<nav class="main-nav">

				<ul>
									<li>	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The form -->
<form class="example" action="process_search1.php" >
  <input type="text" placeholder="Search Yakshagana name"    id="search" name="search1" required>
  <button type="submit"><i class="fa fa-search"></i></button>
</form>
					</li>

					<li><a href="guestview.php">All Events</a></li>
					<li><a href="registration.html">Register</a></li>
					<li><a href="issueform.php">Any issue?</a></li>
					<li><a href="login.php">Login</a></li>
				</ul>
			</nav>
			
		</div>
	
	</div>
		<script>
	function search()
{
	var search = document.getElementById('search').value.toLowerCase();
	var target = document.getElementById("list");
	var list = target.getElementsByTagName('h1');
	for(var i=0; i < list.length; i++){
		var text = list[i].innerHTML;
		if(text.toLowerCase().indexOf(search) > -1){
			list[i].style.display = "";
		}else{
			list[i].style.display = "none";
		}
	}
}
	</script>
	</body>
</html>
	

	
